import { createContext } from "react";

const todosContext = createContext();

export default todosContext;
